"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Gift, Users, Heart, MessageCircle, Trophy, ExternalLink, Share } from "lucide-react"

type GiveawayType = "comments" | "likes" | "reposts" | "all"

interface Winner {
  name: string
  id: string
  userId: number
  profileUrl: string
  type: "comment" | "like" | "repost"
}

export default function VKGiveawayPage() {
  const [postUrl, setPostUrl] = useState("")
  const [giveawayType, setGiveawayType] = useState<GiveawayType>("comments")
  const [isLoading, setIsLoading] = useState(false)
  const [winner, setWinner] = useState<Winner | null>(null)
  const [postData, setPostData] = useState<any>(null)
  const [error, setError] = useState("")

  const VK_TOKEN = "042f9032042f9032042f90323c071637ce0042f042f90326c97f2667ef4750680b91bb9"

  const validateVKUrl = (url: string) => {
    const vkPattern = /^https?:\/\/(www\.)?(vk\.com|m\.vk\.com)\/(wall|post)/
    return vkPattern.test(url)
  }

  const extractPostId = (url: string) => {
    const match = url.match(/wall(-?\d+_\d+)/)
    return match ? match[1] : null
  }

  const fetchVKData = async (postId: string) => {
    const [ownerId, postIdNum] = postId.split("_")

    const response = await fetch("/api/vk-proxy", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        postId,
        ownerId,
        postIdNum,
        token: VK_TOKEN,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error || "Ошибка при получении данных")
    }

    const data = await response.json()
    return data
  }

  const selectRandomWinner = (participants: any[], type: "comment" | "like" | "repost") => {
    if (participants.length === 0) return null
    const randomIndex = Math.floor(Math.random() * participants.length)
    return {
      ...participants[randomIndex],
      type,
    }
  }

  const handleGiveaway = async () => {
    if (!postUrl.trim()) {
      setError("Введите ссылку на пост")
      return
    }

    if (!validateVKUrl(postUrl)) {
      setError("Неверная ссылка на пост ВКонтакте")
      return
    }

    setError("")
    setIsLoading(true)
    setWinner(null)

    try {
      const postId = extractPostId(postUrl)
      if (!postId) {
        throw new Error("Не удалось извлечь ID поста")
      }

      const data = await fetchVKData(postId)
      setPostData(data)

      let participants: any[] = []
      let winnerType: "comment" | "like" | "repost" = "comment"

      switch (giveawayType) {
        case "comments":
          participants = data.comments
          winnerType = "comment"
          break
        case "likes":
          participants = data.likes
          winnerType = "like"
          break
        case "reposts":
          {
            const userReposts = data.reposts || []
            const groupReposts = data.reposts_groups || []
            const meta = data.reposts_meta || { available: true }
            participants = userReposts
            winnerType = "repost"
            if (participants.length === 0) {
              if (!meta.available) {
                throw new Error(
                  meta.reason ||
                    "VK не отдал список репостов. Нужен пользовательский токен с правами wall, likes (и groups).",
                )
              }
              throw new Error(
                groupReposts.length > 0
                  ? "Репосты есть, но все от сообществ. Выберите другой тип розыгрыша."
                  : "Нет участников для розыгрыша по репостам",
              )
            }
          }
          break
        case "all":
          participants = [...data.comments, ...data.likes, ...data.reposts]
          const types: ("comment" | "like" | "repost")[] = ["comment", "like", "repost"]
          winnerType = types[Math.floor(Math.random() * types.length)]
          break
      }

      if (participants.length === 0) {
        throw new Error("Нет участников для розыгрыша")
      }

      const selectedWinner = selectRandomWinner(participants, winnerType)
      setWinner(selectedWinner)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ошибка при получении данных поста")
    } finally {
      setIsLoading(false)
    }
  }

  const resetForm = () => {
    setPostUrl("")
    setWinner(null)
    setPostData(null)
    setError("")
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Gift className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-bold text-foreground">VK Розыгрыши</h1>
          </div>
          <p className="text-lg text-muted-foreground">
            Честные розыгрыши в ВКонтакте. Вставьте ссылку на пост и выберите победителя.
          </p>
        </div>

        {/* Main Form */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ExternalLink className="h-5 w-5" />
              Настройка розыгрыша
            </CardTitle>
            <CardDescription>Введите ссылку на пост ВКонтакте и выберите тип розыгрыша</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* URL Input */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Ссылка на пост ВКонтакте</label>
              <Input
                placeholder="https://vk.com/wall-123456789_123"
                value={postUrl}
                onChange={(e) => setPostUrl(e.target.value)}
                className="text-base"
              />
              {error && <p className="text-sm text-destructive">{error}</p>}
            </div>

            {/* Giveaway Type Selection */}
            <div className="space-y-3">
              <label className="text-sm font-medium">Тип розыгрыша</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <Button
                  variant={giveawayType === "comments" ? "default" : "outline"}
                  onClick={() => setGiveawayType("comments")}
                  className="h-auto p-4 flex flex-col items-center gap-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  <span className="font-medium">Комментарии</span>
                </Button>

                <Button
                  variant={giveawayType === "likes" ? "default" : "outline"}
                  onClick={() => setGiveawayType("likes")}
                  className="h-auto p-4 flex flex-col items-center gap-2"
                >
                  <Heart className="h-5 w-5" />
                  <span className="font-medium">Лайки</span>
                </Button>

                <Button
                  variant={giveawayType === "reposts" ? "default" : "outline"}
                  onClick={() => setGiveawayType("reposts")}
                  className="h-auto p-4 flex flex-col items-center gap-2"
                >
                  <Share className="h-5 w-5" />
                  <span className="font-medium">Репосты</span>
                </Button>

                <Button
                  variant={giveawayType === "all" ? "default" : "outline"}
                  onClick={() => setGiveawayType("all")}
                  className="h-auto p-4 flex flex-col items-center gap-2"
                >
                  <Users className="h-5 w-5" />
                  <span className="font-medium">Все</span>
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button onClick={handleGiveaway} disabled={isLoading} className="flex-1 h-12 text-base font-medium">
                {isLoading ? "Проводим розыгрыш..." : "Начать розыгрыш"}
              </Button>
              <Button variant="outline" onClick={resetForm} className="h-12 px-6 bg-transparent">
                Сбросить
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Post Data */}
        {postData && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Данные поста</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground">{postData.post.text}</p>
                <div className="flex gap-4 flex-wrap">
                  <Badge variant="secondary" className="flex items-center gap-1">
                    <Heart className="h-3 w-3" />
                    {postData.post.likes_count} лайков
                  </Badge>
                  <Badge variant="secondary" className="flex items-center gap-1">
                    <MessageCircle className="h-3 w-3" />
                    {postData.post.comments_count} комментариев
                  </Badge>
                  <Badge variant="secondary" className="flex items-center gap-1">
                    <Share className="h-3 w-3" />
                    {postData.post.reposts_count} репостов
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Winner Display */}
        {winner && (
          <Card className="border-primary/20 bg-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <Trophy className="h-6 w-6" />
                Поздравляем победителя!
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-4">
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-foreground">{winner.name}</div>
                  <a
                    href={winner.profileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
                  >
                    <ExternalLink className="h-4 w-4" />
                    Перейти в профиль ВК
                  </a>
                </div>
                <Badge variant="default" className="text-sm">
                  {winner.type === "comment"
                    ? "Выбран из комментариев"
                    : winner.type === "like"
                      ? "Выбран из лайков"
                      : "Выбран из репостов"}
                </Badge>
                <Separator />
                <p className="text-sm text-muted-foreground">
                  Победитель выбран случайным образом из{" "}
                  {giveawayType === "comments"
                    ? "комментаторов"
                    : giveawayType === "likes"
                      ? "лайкнувших"
                      : giveawayType === "reposts"
                        ? "репостнувших"
                        : "всех участников"}
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
