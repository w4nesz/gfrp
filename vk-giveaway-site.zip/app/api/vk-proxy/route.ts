import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { postId, ownerId, postIdNum, token } = await request.json()

    console.log("[v0] Received request:", { postId, ownerId, postIdNum })

    const makeVKRequest = async (url: URL) => {
      console.log("[v0] Making VK request to:", url.toString())

      const response = await fetch(url.toString(), {
        headers: {
          Accept: "application/json",
          "User-Agent": "VKGiveawayBot/1.0",
        },
      })

      console.log("[v0] Response status:", response.status)
      console.log("[v0] Response headers:", Object.fromEntries(response.headers.entries()))

      const text = await response.text()
      console.log("[v0] Response text (first 200 chars):", text.substring(0, 200))

      const contentType = response.headers.get("content-type")
      const isLikelyJson = contentType && (contentType.includes("json") || contentType.includes("javascript"))
      if (!isLikelyJson) {
        throw new Error(`VK API вернул неожиданный тип контента: ${contentType}. Ответ: ${text.substring(0, 100)}`)
      }

      if (!response.ok) {
        throw new Error(`HTTP ошибка: ${response.status} ${response.statusText}. Ответ: ${text}`)
      }

      try {
        return JSON.parse(text)
      } catch (parseError) {
        throw new Error(`Ошибка парсинга JSON: ${parseError}. Ответ: ${text.substring(0, 200)}`)
      }
    }

    // Получаем данные поста
    const postUrl = new URL("https://api.vk.com/method/wall.getById")
    postUrl.searchParams.append("posts", `${ownerId}_${postIdNum}`)
    postUrl.searchParams.append("access_token", token)
    postUrl.searchParams.append("v", "5.131")

    const postData = await makeVKRequest(postUrl)

    if (postData.error) {
      throw new Error(`Ошибка получения поста: ${postData.error.error_msg} (код: ${postData.error.error_code})`)
    }

    if (!postData.response || postData.response.length === 0) {
      throw new Error("Пост не найден. Проверьте ссылку и убедитесь, что пост публичный.")
    }

    const getAllComments = async () => {
      const allComments = []
      let offset = 0
      const limit = 100

      while (true) {
        const commentsUrl = new URL("https://api.vk.com/method/wall.getComments")
        commentsUrl.searchParams.append("owner_id", ownerId)
        commentsUrl.searchParams.append("post_id", postIdNum)
        commentsUrl.searchParams.append("access_token", token)
        commentsUrl.searchParams.append("v", "5.131")
        commentsUrl.searchParams.append("count", limit.toString())
        commentsUrl.searchParams.append("offset", offset.toString())
        commentsUrl.searchParams.append("extended", "1")

        const commentsData = await makeVKRequest(commentsUrl)

        if (commentsData.error) {
          console.warn(
            `[v0] Комментарии недоступны: ${commentsData.error.error_msg} (код: ${commentsData.error.error_code}). Возвращаем пусто.`,
          )
          return allComments
        }

        const comments = commentsData.response?.items || []
        allComments.push(...comments)

        console.log(`[v0] Получено комментариев: ${comments.length}, всего: ${allComments.length}`)

        if (comments.length < limit) break
        offset += limit
      }

      return allComments
    }

    const getAllLikes = async () => {
      const allLikes = []
      let offset = 0
      const limit = 1000

      while (true) {
        const likesUrl = new URL("https://api.vk.com/method/likes.getList")
        likesUrl.searchParams.append("type", "post")
        likesUrl.searchParams.append("owner_id", ownerId)
        likesUrl.searchParams.append("item_id", postIdNum)
        likesUrl.searchParams.append("access_token", token)
        likesUrl.searchParams.append("v", "5.131")
        likesUrl.searchParams.append("count", limit.toString())
        likesUrl.searchParams.append("offset", offset.toString())

        const likesData = await makeVKRequest(likesUrl)

        if (likesData.error) {
          console.warn(
            `[v0] Лайки недоступны: ${likesData.error.error_msg} (код: ${likesData.error.error_code}). Возвращаем пусто.`,
          )
          return allLikes
        }

        const likes = likesData.response?.items || []
        allLikes.push(...likes)

        console.log(`[v0] Получено лайков: ${likes.length}, всего: ${allLikes.length}`)

        if (likes.length < limit) break
        offset += limit
      }

      return allLikes
    }

    const getAllReposts = async () => {
      // Сначала пытаемся получить ID пользователей, сделавших репост, через likes.getList с filter=copies
      const allRepostUserIds: number[] = []
      let offset = 0
      const limit = 1000

      while (true) {
        const copiesUrl = new URL("https://api.vk.com/method/likes.getList")
        copiesUrl.searchParams.append("type", "post")
        copiesUrl.searchParams.append("owner_id", ownerId)
        copiesUrl.searchParams.append("item_id", postIdNum)
        copiesUrl.searchParams.append("filter", "copies")
        copiesUrl.searchParams.append("count", limit.toString())
        copiesUrl.searchParams.append("offset", offset.toString())
        copiesUrl.searchParams.append("access_token", token)
        copiesUrl.searchParams.append("v", "5.131")

        const copiesData = await makeVKRequest(copiesUrl)

        if (copiesData.error) {
          if (copiesData.error.error_code === 15) {
            console.warn("[v0] Доступ к списку репостов запрещен. Пост может быть приватным.")
            break
          }
          console.warn(`[v0] Ошибка получения репостов (copies): ${copiesData.error.error_msg}`)
          break
        }

        const items: number[] = copiesData.response?.items || []
        allRepostUserIds.push(...items)

        console.log(`[v0] Получено репостеров (copies): ${items.length}, всего: ${allRepostUserIds.length}`)

        if (items.length < limit) break
        offset += limit
      }

      // Если метод copies не вернул пользователей, но у поста есть репосты по счетчику,
      // пробуем фоллбек на wall.getReposts (по страницам берём from_id из items)
      const repostsCount = Number(postData?.response?.[0]?.reposts?.count || 0)
      if (allRepostUserIds.length === 0 && repostsCount > 0) {
        console.log("[v0] Фоллбек: пробуем wall.getReposts, так как copies вернул 0 при count=", repostsCount)
        const dedupUserIds = new Set<number>()
        let offset2 = 0
        const pageSize = 100

        while (true) {
          const wrUrl = new URL("https://api.vk.com/method/wall.getReposts")
          wrUrl.searchParams.append("owner_id", ownerId)
          wrUrl.searchParams.append("post_id", postIdNum)
          wrUrl.searchParams.append("count", pageSize.toString())
          wrUrl.searchParams.append("offset", offset2.toString())
          wrUrl.searchParams.append("access_token", token)
          wrUrl.searchParams.append("v", "5.131")

          const wrData = await makeVKRequest(wrUrl)

          if (wrData.error) {
            if (wrData.error.error_code === 15) {
              console.warn("[v0] Доступ к wall.getReposts запрещен. Пропускаем.")
              break
            }
            console.warn(`[v0] Ошибка wall.getReposts: ${wrData.error.error_msg}`)
            break
          }

          const wrItems: any[] = wrData.response?.items || []
          // Для repost-объектов ID репостера находится в owner_id (а не from_id)
          // Сохраняем как положительные (пользователи), так и отрицательные (сообщества) ID
          const pageOwnerIds = wrItems
            .map((it: any) => (typeof it?.owner_id === "number" ? it.owner_id : null))
            .filter((id: number | null) => typeof id === "number") as number[]
          pageOwnerIds.forEach((id) => dedupUserIds.add(id))

          console.log(
            `[v0] wall.getReposts страница: items=${wrItems.length}, новых id=${pageOwnerIds.length}, всего=${dedupUserIds.size}`,
          )

          if (wrItems.length < pageSize) break
          offset2 += pageSize
        }

        return Array.from(dedupUserIds)
      }

      return allRepostUserIds
    }

    const allComments = await getAllComments()
    const allLikes = await getAllLikes()
    const allReposts = await getAllReposts()

    // Получаем информацию о пользователях
    const userIds = [
      ...allComments.map((c: any) => c.from_id),
      ...allLikes,
      ...allReposts,
    ].filter((id) => id > 0) // только пользователи, не группы

    const getUsersInBatches = async (userIds: number[], batchSize = 100) => {
      const usersMap = new Map()

      for (let i = 0; i < userIds.length; i += batchSize) {
        const batch = userIds.slice(i, i + batchSize)

        const usersUrl = new URL("https://api.vk.com/method/users.get")
        usersUrl.searchParams.append("user_ids", batch.join(","))
        usersUrl.searchParams.append("fields", "screen_name")
        usersUrl.searchParams.append("lang", "ru")
        usersUrl.searchParams.append("access_token", token)
        usersUrl.searchParams.append("v", "5.131")

        try {
          const usersData = await makeVKRequest(usersUrl)

          if (usersData.error) {
            console.warn(`[v0] Ошибка получения пользователей в батче: ${usersData.error.error_msg}`)
            continue
          }

          usersData.response?.forEach((user: any) => {
            usersMap.set(user.id, {
              name: `${user.first_name} ${user.last_name}`,
              profileUrl: `https://vk.com/${user.screen_name || `id${user.id}`}`,
            })
          })
        } catch (error) {
          console.warn(`[v0] Ошибка в батче пользователей:`, error)
          continue
        }
      }

      return usersMap
    }

    console.log(`[v0] Получаем информацию о ${userIds.length} уникальных пользователях`)

    const usersMap = await getUsersInBatches(userIds)

    // Получаем информацию о сообществах, которые сделали репосты (отрицательные ID)
    const groupIds = Array.from(new Set((allReposts as number[]).filter((id) => id < 0).map((id) => Math.abs(id))))
    const getGroupsInBatches = async (groupIds: number[], batchSize = 500) => {
      const groupsMap = new Map()
      for (let i = 0; i < groupIds.length; i += batchSize) {
        const batch = groupIds.slice(i, i + batchSize)

        const groupsUrl = new URL("https://api.vk.com/method/groups.getById")
        groupsUrl.searchParams.append("group_ids", batch.join(","))
        groupsUrl.searchParams.append("fields", "screen_name")
        groupsUrl.searchParams.append("access_token", token)
        groupsUrl.searchParams.append("v", "5.131")

        try {
          const groupsData = await makeVKRequest(groupsUrl)
          if (groupsData.error) {
            console.warn(`[v0] Ошибка получения сообществ в батче: ${groupsData.error.error_msg}`)
            continue
          }
          ;(groupsData.response || []).forEach((group: any) => {
            groupsMap.set(group.id, {
              name: group.name,
              profileUrl: `https://vk.com/${group.screen_name || `club${group.id}`}`,
            })
          })
        } catch (error) {
          console.warn(`[v0] Ошибка в батче сообществ:`, error)
          continue
        }
      }
      return groupsMap
    }

    const groupsMap = await getGroupsInBatches(groupIds)

    const comments = allComments.map((comment: any) => {
      const userInfo = usersMap.get(comment.from_id)
      return {
        id: comment.id.toString(),
        userId: comment.from_id,
        name: userInfo?.name || "Пользователь",
        profileUrl: userInfo?.profileUrl || `https://vk.com/id${comment.from_id}`,
        text: comment.text,
      }
    })

    const likes = allLikes.map((userId: number) => {
      const userInfo = usersMap.get(userId)
      return {
        id: userId.toString(),
        userId: userId,
        name: userInfo?.name || "Пользователь",
        profileUrl: userInfo?.profileUrl || `https://vk.com/id${userId}`,
      }
    })

    const reposts = (allReposts as number[])
      .filter((id) => id > 0)
      .map((userId: number) => {
        const userInfo = usersMap.get(userId)
        return {
          id: userId.toString(),
          userId,
          name: userInfo?.name || "Пользователь",
          profileUrl: userInfo?.profileUrl || `https://vk.com/id${userId}`,
        }
      })

    const reposts_groups = (allReposts as number[])
      .filter((id) => id < 0)
      .map((negId: number) => {
        const groupId = Math.abs(negId)
        const groupInfo = groupsMap.get(groupId)
        return {
          id: `-${groupId}`,
          groupId,
          name: groupInfo?.name || "Сообщество",
          profileUrl: groupInfo?.profileUrl || `https://vk.com/club${groupId}`,
        }
      })

    const reposts_count_vk = Number(postData.response[0]?.reposts?.count || 0)
    const totalResolvedReposts = (reposts?.length || 0) + (reposts_groups?.length || 0)
    const reposts_available = !(reposts_count_vk > 0 && totalResolvedReposts === 0)
    const reposts_unavailable_reason = reposts_available
      ? undefined
      : "Список репостов недоступен для этого токена/поста (нужен user access_token с правами wall, likes; возможна приватность)."

    const result = {
      comments,
      likes,
      reposts,
      reposts_groups,
      post: {
        text: postData.response[0]?.text || "",
        likes_count: likes.length,
        comments_count: comments.length,
        // отображаем реальный счетчик из VK (он включает репосты сообществ)
        reposts_count: reposts_count_vk,
      },
      reposts_meta: { available: reposts_available, reason: reposts_unavailable_reason },
    }

    console.log("[v0] Final result:", {
      commentsCount: comments.length,
      likesCount: likes.length,
      repostsCount: reposts.length,
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("[v0] VK API Error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Ошибка при получении данных из VK API" },
      { status: 500 },
    )
  }
}
