import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Trophy } from "lucide-react"

interface Winner {
  name: string
  id: string
  type: "comment" | "like"
}

interface WinnerDisplayProps {
  winner: Winner
  giveawayType: "comments" | "likes" | "both"
}

export function WinnerDisplay({ winner, giveawayType }: WinnerDisplayProps) {
  return (
    <Card className="border-primary/20 bg-primary/5">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-primary">
          <Trophy className="h-6 w-6" />
          Поздравляем победителя!
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center space-y-4">
          <div className="text-2xl font-bold text-foreground">{winner.name}</div>
          <Badge variant="default" className="text-sm">
            {winner.type === "comment" ? "Выбран из комментариев" : "Выбран из лайков"}
          </Badge>
          <Separator />
          <p className="text-sm text-muted-foreground">
            Победитель выбран случайным образом из{" "}
            {giveawayType === "comments"
              ? "комментаторов"
              : giveawayType === "likes"
                ? "лайкнувших"
                : "всех участников"}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
