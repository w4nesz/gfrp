"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageCircle, Heart, Users, ExternalLink } from "lucide-react"

interface GiveawayFormProps {
  onSubmit: (url: string, type: "comments" | "likes" | "both") => void
  isLoading: boolean
  error: string
}

export function GiveawayForm({ onSubmit, isLoading, error }: GiveawayFormProps) {
  const [postUrl, setPostUrl] = useState("")
  const [giveawayType, setGiveawayType] = useState<"comments" | "likes" | "both">("comments")

  const handleSubmit = () => {
    onSubmit(postUrl, giveawayType)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ExternalLink className="h-5 w-5" />
          Настройка розыгрыша
        </CardTitle>
        <CardDescription>Введите ссылку на пост ВКонтакте и выберите тип розыгрыша</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-medium">Ссылка на пост ВКонтакте</label>
          <Input
            placeholder="https://vk.com/wall-123456789_123"
            value={postUrl}
            onChange={(e) => setPostUrl(e.target.value)}
            className="text-base"
          />
          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>

        <div className="space-y-3">
          <label className="text-sm font-medium">Тип розыгрыша</label>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Button
              variant={giveawayType === "comments" ? "default" : "outline"}
              onClick={() => setGiveawayType("comments")}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <MessageCircle className="h-5 w-5" />
              <span className="font-medium">По комментариям</span>
              <span className="text-xs opacity-80">Случайный комментатор</span>
            </Button>

            <Button
              variant={giveawayType === "likes" ? "default" : "outline"}
              onClick={() => setGiveawayType("likes")}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <Heart className="h-5 w-5" />
              <span className="font-medium">По лайкам</span>
              <span className="text-xs opacity-80">Случайный лайкнувший</span>
            </Button>

            <Button
              variant={giveawayType === "both" ? "default" : "outline"}
              onClick={() => setGiveawayType("both")}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <Users className="h-5 w-5" />
              <span className="font-medium">Комментарии + лайки</span>
              <span className="text-xs opacity-80">Все участники</span>
            </Button>
          </div>
        </div>

        <Button onClick={handleSubmit} disabled={isLoading} className="w-full h-12 text-base font-medium">
          {isLoading ? "Проводим розыгрыш..." : "Начать розыгрыш"}
        </Button>
      </CardContent>
    </Card>
  )
}
